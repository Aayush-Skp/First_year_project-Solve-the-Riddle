  /* Header files */
  #include<iostream>
  #include<cstdlib>
  #include<ctime>
  #include <Windows.h>
  #include<mmsystem.h>
  #include<iomanip>
  #include<fstream>
  #include<string>
/*----------------------------------------------------------------------------------------------
   #)Comments regarding the different phrase of codes

   1.the value passed in function sleep is in millisecond
   2.
   3.
 ----------------------------------------------------------------------------------------------*/
using namespace std;

//This function is for setting option.
/*----------------------------------------------------------------------------------------------*/
void setting(int &x)
{
    int choice;
    cout<<"\n\t"<<"Choose an option: \n\t1.Sound effects activation\n\t2.Change the theme."<<endl;
    cin>>choice;
    if(choice==1)
    {
        char activate;
        cout<<"\n\tDisclaimer: your sound effect activation may cause slow pace in program speed!\n\t   So then,Do you want sound effect:(y/n): "; cin>>activate;
        if(activate=='y' || activate=='Y')
        {
           x=1;
        }
    }
    else if(choice==2)
    {
        int col;
        cout<<"\n\t"<<"which theme you want:\n\t1.Blue \n\t2.Aqua \n\t3.Green \n\t4.Purple \n\t5.Green with default black BG"<<endl;
        cin>>col;
switch (col)
{
case 1:
    system("color 1f");
    break;
case 2:
    system("color 7d");
    break;
case 3:
    system("color 2f");
    break;
case 4:
    system("color 5e");
    break;
case 5:
    system("color 02");
    break;
    default:
    printf("\n Invalid option\n");

}
    }
}

//This function is to check whether the login information given by user is right or wrong!
/*----------------------------------------------------------------------------------------------*/
bool isloggedin(string &x,string &y,int &z)
{
    string username,password,un,pw;
    cout<<"\tEnter the username: "; cin>>username;
    cout<<"\tEnter the password: "; cin>>password;

    ifstream read("STRusers\\" + username +".txt");
    read>>un>>pw>>z;

    if(un==username && pw==password)
       {
           x=username;     //It sends the currently entered user name to main function.
           y=password;
           return true;
       }
       else{ return false;}
}

//This function provides first interface to login or register!
/*----------------------------------------------------------------------------------------------*/
int startp(string &x,string &y,int &z,int &p){
  start:
  system("cls");
  int choice;

       cout<<"--------------------------------------------------------------------------------------------------------------";
       cout<<"\n                                               SOLVE THE RIDDLE\n";
       cout<<"                                               -----------------                                           ";
       cout<<"\n--------------------------------------------------------------------------------------------------------------"<<endl;


  cout<<"\t1:Register\n\t2:Login\n\t3.Details on game mechanics!\n\t4.Setting"<<endl; cin>>choice;
  if(choice==1)
   {
    string username,password;
    cout<<"\tEnter you Username: "; cin>>username;
    cout<<"\tEnter you Password: "; cin>>password;

    ofstream file;
    file.open("STRusers\\" + username +  ".txt");
    file<<username<<"\t"<<password<<"\n"<<z;
    file.close();
    system("cls");
     goto start; }

     else if(choice==2)
     {
         bool status=isloggedin(x,y,z);

         if (!status)
         {
             cout<<"\t-----------------------\n";
             cout<<"\t   Your login failed!!"<<endl;
             cout<<"\t-----------------------\n";
             PlaySound(TEXT("soundeffect\\wrong.wav"),NULL,SND_SYNC);
             //system("PAUSE");
             return 0;
         }
         else{
            cout<<"\t-----------------------\n";
            cout<<"\t   login sucessfull!"<<endl;
            cout<<"\t-----------------------\n";
            PlaySound(TEXT("soundeffect\\right.wav"),NULL,SND_SYNC);
            //system("PAUSE");
            return 1;
         }
     }
     else if(choice==3)
     {
         system("start https://projectdetail7.blogspot.com/");
         goto start;
     }
     else if(choice==4)
     {
         setting(p);
         goto start;
     }
    }

//This function is for countdown
/*----------------------------------------------------------------------------------------------*/
void timer()
{
    for(int i=7;i>=0;i--)
    {
        //system("cls");
        cout<<setw(2)<<i;
        Sleep(500);
        Beep(523,500);
    }
    system("cls");
}

//This function is for quiz(option 2)
/*----------------------------------------------------------------------------------------------*/
 int Randomriddle()
 {
    system("cls");
    srand(time(0));
    int a=(rand()%7)+1;
 cout<<"\n\t"<<"Here is your qn:"<<"\n\t";

 switch(a)
 {
 case 1:
    cout<<"Q.What has to be broken before you can use it?"<<endl;
    break;
    case 2:
    cout<<"Q.I am tall when I�m young, and I am short when I am old. What am I?"<<endl;
    break;
    case 3:
    cout<<"Q.What is full of holes but still holds water?"<<endl;
    break;
    case 4:
    cout<<"Q.What goes up but never comes down?"<<endl;
    break;
    case 5:
    cout<<"Q.What is always in front of you but can�t be seen?"<<endl;
    break;
    case 6:
    cout<<"Q.What can you break, even if you never pick it up or touch it?"<<endl;
    break;
    case 7:
    cout<<"Q.What invention lets you look right through a wall?"<<endl;
    break;
 }
 cout<<"\n\t"<<"Your question visibility ends in : ";
 timer();
 return a;
 }

//This function is for guess the number(option 1)
/*----------------------------------------------------------------------------------------------*/
bool guessthenumber()
{
    system("cls");
    int num,randomno;
    randomno=rand()%10+1;
    for(int i=2;i>0;i--)
    {
      cout<<"\n\t"<<"Guess the number between 1-10(You have "<<i<<" chance): "<<"\n\t"; cin>>num;
      if(num==randomno)
     {
         return 1;
         exit(1);
     }

    } return 0;


}

 //Base class where all fragments of questions are kept
 /*----------------------------------------------------------------------------------------------*/
class parts
{   public:
    string one[12]={"if you are","i have cities,but no","i have keys,but","Which","what comes once in a","If you have me,You will want to","I am always","I","This is","David's","What","what has a"};

    string two[12]={" invisible,"," houses."," no locks"," word"," minute"," share"," hungry"," shave"," easy"," father"," disappears"," head"};

    string three[12]={" and if you close your"," i have mountains,but no"," and space, and"," in the"," twice in a"," me. if you"," and will die if not"," everyday but my"," to"," has three"," as soon as you"," and a" };

    string four[12]={" eye,"," trees."," no rooms."," dictionary"," moment"," share"," fed"," beard"," lift"," sons:"," say"," tail"};

    string five[12]={" would you even able to"," i have water,but no"," you can"," is always spelled"," but never in"," me,you will"," but whatever i"," stays the"," but hard to"," snap,crack"," it's"," but no"};

    string six[12]={" see"," fish"," enter,"," incorrectly"," a thousand"," no longer"," touch"," same"," throw"," and"," name"," body"};

    string seven[12]={" anything?"," what am i?"," but you can't go outside."," ?"," years"," have me. what am i?"," will soon turn red!"," who am i?"," what is it?"," ......?"," ?"," ?"};
};

//From here, there are four child classes that initialize the four stages for each question.
/*----------------------------------------------------------------------------------------------*/
class stageone:public parts
{
   public:

   void display(int a){
   cout<<"\n--------------------------------------------------------------------------------------------------------------";
   cout<<"\n                                               STAGE_ONE\n";
   cout<<"                                              -----------                                           ";
   cout<<"\n\t"<<"Incomplete Question no ["<<a+1<<"] is:\n\t"<<one[a]<<" *_______*"<<three[a]<<" *_______*"<<five[a]<<" *_______*"<<seven[a]<<endl;
   cout<<"\n--------------------------------------------------------------------------------------------------------------";
   }
};

class stagetwo:public parts
{
   public:

   void display(int a){
   cout<<"\n--------------------------------------------------------------------------------------------------------------";
   cout<<"\n                                               STAGE_TWO\n";
   cout<<"                                              -----------                                           ";
   cout<<"\n\t"<<one[a]<<two[a]<<three[a]<<" *_______*"<<five[a]<<" *_______*"<<seven[a]<<endl;
   cout<<"\n--------------------------------------------------------------------------------------------------------------";
   }
};
class stagethree:public parts
{
   public:

   void display(int a){
   cout<<"\n--------------------------------------------------------------------------------------------------------------";
   cout<<"\n                                               STAGE_THREE\n";
   cout<<"                                               -----------                                           ";
   cout<<"\n\t"<<one[a]<<two[a]<<three[a]<<four[a]<<five[a]<<" *_______*"<<seven[a]<<endl;
   cout<<"\n--------------------------------------------------------------------------------------------------------------";
   }
};
class stagefour:public parts
{
   public:

   void display(int a){
   cout<<"\n--------------------------------------------------------------------------------------------------------------";
   cout<<"\n                                               FINAL_STAGE\n";
   cout<<"                                               -----------                                           ";
   cout<<"\n\t"<<one[a]<<two[a]<<three[a]<<four[a]<<five[a]<<six[a]<<seven[a]<<endl;
   cout<<"\n--------------------------------------------------------------------------------------------------------------";
   }
};

//Function for the options that gets provided during each blank filling stage
/*----------------------------------------------------------------------------------------------*/
bool twooptions(int eff)
{
     int choice;
    cout<<"\n\n\tChoose one option to fill first blank: \n\t1.Play guess the number game\n\t2.Play quize"<<endl;
    Sleep(500);
    if(eff==1){PlaySound(TEXT("soundeffect\\chooseoption.wav"),NULL,SND_SYNC);}
    cin>>choice;
    if(choice==2)
    {
    int r;
    string answer;
    string answers[8]={"null","egg","candle","sponge","age","future","promise","window"};
    r=Randomriddle();

    cout<<"\n\t"<<"What is your answer: ";
     cin>>answer;
    if(answer==answers[r])
    {
     return 1;
    }
    else {return 0;}

    }
    else if(choice==1)
    {
      bool j=guessthenumber();
      if (j)
      {
          return 1;
      } else{return 0;}
      }

}

/******************************Main function starts from here!***********************************/
/*----------------------------------------------------------------------------------------------*/
int main()
{
    system("title SOLVE THE RIDDLE"); //it changes the name of cmd window

    int silverbatch=0,level=0,effect=0;
    float champbatch=0;
    string answer,name,pass;
    string answers[12]={"yes","map","keyboard","incorrectly","m","secret","fire","barber","feather","david","silence","coin"}; //answers of all questions
    strartofprogram:
    bool in=startp(name,pass,level,effect);



    if(in)     //program only starts if the startup i.e.login succeeds(returns 1).
   {
     system("cls");
     cout<<endl<<endl<<"\t\t\twelcome "<<name<<" ,so you decided to spare some time while solving some riddle";
                                         cout<<"\n\t\t\t\twith us. thank you!"<<" You currently are in level "<<level<<"."<<endl;
                                         cout<<"\n--------------------------------------------------------------------------------------------------------------"<<endl;
                                         cout<<"\t\t\tNOTE:YOU CAN ONLY ANSWER IN ONE WORD FOR ANY QUESTION AND IN SMALL ALPHABETS!";

     if(effect==1){PlaySound(TEXT("soundeffect\\welcome3.wav"),NULL,SND_SYNC); }  //it plays sound effect for welcome phrase.
        else {Sleep(700);}                                                   //if sound effect is not activated screen holds for 0.7sec


    for(int i=level;i<12;i++)  //this loop continues for 1-12 questions in the program
    {

    //This is for first stage of question
    again:
    stageone first;
    first.display(i);

    if(twooptions(effect))
    {
        silverbatch+=1;
        cout<<"\n\t"<<"Congrats! you got that"<<endl;
        if(effect==1){PlaySound(TEXT("soundeffect\\congrats.wav"),NULL,SND_SYNC); } //this line is for sound effect only.
    }
           else{cout<<"\n\t"<<"sorry! that was wrong"<<endl;
                if(effect==1){PlaySound(TEXT("soundeffect\\sorry.wav"),NULL,SND_SYNC); }}  //this line is for sound effect only.


    //This is for Second stage of question
    stagetwo second;
    second.display(i);

    if(twooptions(effect))
    {
        silverbatch+=1;
        cout<<"\n\t"<<"Congrats! you got that"<<endl;
        if(effect==1){PlaySound(TEXT("soundeffect\\congrats.wav"),NULL,SND_SYNC); }  //this line is for sound effect only.
    }
              else{cout<<"\n\t"<<"sorry! that was wrong"<<endl;
                    if(effect==1){PlaySound(TEXT("soundeffect\\sorry.wav"),NULL,SND_SYNC); }}  //this line is for sound effect only.


    //This is for Third stage of question
    stagethree third;
    third.display(i);

    if(twooptions(effect))
    {
        silverbatch+=1;
        cout<<"\n\t"<<"Congrats! you got that"<<endl;
        if(effect==1){PlaySound(TEXT("soundeffect\\congrats.wav"),NULL,SND_SYNC); }  //this line is for sound effect only.
    }
               else{cout<<"\n\t"<<"sorry! that was wrong"<<endl;
                   if(effect==1){PlaySound(TEXT("soundeffect\\sorry.wav"),NULL,SND_SYNC); }}     //this line is for sound effect only.


     //This lines of program gives you how many stages you went winning.
    cout<<"\n\t"<<"your silverbatch is: "<<silverbatch<<endl;
    Sleep(2500);


    //This is for Fourth stage of question
    stagefour fourth;
    fourth.display(i);
      cout<<endl<<"\t\t\tNOTE:YOU CAN ONLY ANSWER IN ONE WORD FOR EACH QUESTION AND IN SMALL ALPHABETS!";
      cout<<"\n--------------------------------------------------------------------------------------------------------------"<<endl;
      cout<<"\n\t"<<"Let the answer decide your I.Q. Enter your answer:";
         if(effect==1){PlaySound(TEXT("soundeffect\\decideiq.wav"),NULL,SND_SYNC); } cin>>answer;  //this line is for sound effect only.




    //Checks the answer and if it's correct updates the users progress(level).
    if(answer==answers[i])
    {
      champbatch=champbatch+1+0.1*silverbatch;
      level+=1;
      ofstream saveprogress;
      saveprogress.open("STRusers\\\n" + name +  ".txt");
      saveprogress<<level;
      saveprogress.close();


       //opens the file and updates the users progress.
       ofstream file;
       file.open("STRusers\\" + name +  ".txt",ios::trunc);
       file<<name<<"\t"<<pass<<"\n"<<level;
       file.close();
      cout<<"\n\t"<<"congrats! You have "<<champbatch<<" champBatch now. Your progress has been updated."<<endl;
             if(effect==1){PlaySound(TEXT("soundeffect\\progressupdated.wav"),NULL,SND_SYNC); }   //this line is for sound effect only.

         } //loop ends for right answer!
               else{cout<<"\n\t"<<"sorry you missed the right answer. Better try next time"<<endl;
                    if(effect==1){PlaySound(TEXT("soundeffect\\nexttime.wav"),NULL,SND_SYNC); } //this line is for sound effect only.
                  champbatch=champbatch-0.1*silverbatch;
                  goto again;
                  }   //this above code activates if answer is wrong

            }//Ends the of loop for the questions.
         }//if login succeeds above code will run.

        else
            {  system("cls");
        cout<<endl<<"\n\t"<<"-------You are restricted to play further.-------"<<endl<<endl;
                if(effect==1){PlaySound(TEXT("soundeffect\\restricted.wav"),NULL,SND_SYNC); }     //this line is for sound effect only.
                Sleep(1000);
                goto strartofprogram; } //If login fails above code run.

    return 0;

} //Main function ends here.
